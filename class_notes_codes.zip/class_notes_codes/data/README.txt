Reference for fruits.xlsx and fruits.csv

http://recipes.albertarose.org/calorie_charts/fruit_chart.htm