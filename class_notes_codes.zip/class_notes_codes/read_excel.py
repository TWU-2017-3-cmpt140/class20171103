#*****************************************************************
# This file demostrate some of the Python operations related to
# reading excel file using the openpyxl package.
#
# reference:
#     http://www.python-excel.org/
#     https://openpyxl.readthedocs.io/en/default/
#*****************************************************************

# install it using pip
# in command prompt, do the following:
# > pip install openpyxl

# load package
from openpyxl import load_workbook
# open a file
wb = load_workbook('data\\fruits.xlsx')

# get the worksheet name
wb.get_sheet_names()

# get a worksheet
ws = wb["Sheet1"]

# to get the value of a cell in "A1"
ws["A1"].value

# to get the maximum number of rows, columns on the worksheet
ws.max_row, ws.max_column

# let's try to read in this excel file into a dictionary
# assuming the first row is a header
#
# key = (fruit, amount)
# value = calories
#
# method 1: read in value one by one
fruitChart = {}
for i in range(1,ws.max_row):
    fruitChart[(ws["A"+str(i)].value,ws["B"+str(i)].value)] = ws["C"+str(i)].value
    
# method 2: using list comprehension
fruitChart = {}
col1 = [a.value for a in list(ws.columns)[0]]
col2 = [a.value for a in list(ws.columns)[1]]
col3 = [a.value for a in list(ws.columns)[2]]   
for index,key in enumerate(zip(col1[1:],col2[1:])):
   fruitChart[key] = col3[index+1]




