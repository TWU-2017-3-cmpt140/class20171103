#*****************************************************************
# This file demostrate some of the Python operations related to
# writing plain text file.
#*****************************************************************

# open file
f = open("data/out1.txt","w")

# try writing a list of values
li = [i.strip() for i in open("data/fruits.txt")]
for x in li:
   f.write(x)
f.close()
# the output from above does not have any line break

# writing a list of values with line breaks
f = open("data/out1.txt","w")
li = [i.strip() for i in open("data/fruits.txt")]
for x in li:
   f.write(x+"\n") # "\n" = new line character
f.close()


