#*****************************************************************
# This file demostrate some of the Python operations related to
# writing excel file using the openpyxl package.
#
# reference:
#     http://www.python-excel.org/
#     https://openpyxl.readthedocs.io/en/default/
#*****************************************************************

# install it using pip
# in command prompt, do the following:
# > pip install openpyxl

# load package
from openpyxl import Workbook

# create a workbook
wb = Workbook()

# default, there is one sheet already
wb.get_sheet_names()

# create a worksheet
ws = wb.create_sheet(title="TEST1")

# add some values to it
ws["A1"] = 123

# save to Excel file
wb.save(filename="data\\out1.xlsx")


# let's try to read in the fruit data file, make some modification and
# write results to excel file
# load package
from openpyxl import load_workbook
# open a file and get worksheet
wb = load_workbook('data\\fruits.xlsx')
ws = wb["Sheet1"]
    
# read in data to dictionary
fruitChart = {}
col1 = [a.value for a in list(ws.columns)[0]]
col2 = [a.value for a in list(ws.columns)[1]]
col3 = [a.value for a in list(ws.columns)[2]]   
for index,key in enumerate(zip(col1[1:],col2[1:])):
   fruitChart[key] = col3[index+1]


# let's do some data modification
# change the word "cup" to "250mL"
for key, value in fruitChart.items():
   if key[1]=="cup":
      fruitChart[(key[0],"250mL")] = value
      del(fruitChart[key])

# write data to file
# header
ws["A1"] = "Fruit"
ws["B1"] = "Amount"
ws["C1"] = "Calories"

for i, key in enumerate(fruitChart):
   ws["A"+str(i+2)] = key[0]
   ws["B"+str(i+2)] = key[1]
   ws["C"+str(i+2)] = fruitChart[key]

# write to file
wb.save(filename="data\\out2.xlsx")

   



