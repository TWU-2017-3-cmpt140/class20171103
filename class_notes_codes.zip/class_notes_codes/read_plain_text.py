#*****************************************************************
# This file demostrate some of the Python operations related to
# reading plain text file.
#*****************************************************************

# use Python to open the file data/fruits.txt
# please note, the file "fruits.txt" is in the folder data
f = open("data/fruits.txt")

# we need to read the f line by line until it reach the end of file
# There are a couple of ways to do it.

# Method 1: use for loop
for i in f:
   print(i)
   
# Method 2: use while loop and next() function
f = open("data/fruits.txt")
while True:
   try:
      i = next(f)
      print(i)
   except: # encounter StopIteration
           # exception - i.e. when
           # finished reading files.
      break

# use method 1 to store the data from "data/fruits.txt" into a list
f = open("data/fruits.txt")
li = []
for i in f:
   li.append(i)
# or you can make a list out of f using list comprehension
li = [i for i in open("data/fruits.txt")]

# Do some text processing while reading the file
li = [i.strip() for i in open("data/fruits.txt")]

# try reading in a CSV file containing information on
# nutrition values for various fruits
#
# the format of the csv file:
# Fruit   Amount    Calories
# Apple   medium    60
# Apple   Juice	cup 115
# Apricot 3 medium  50
#
# try to read it as a dictionary with key as (fruit,amount)
# and value is calories
f = open("data/fruits.csv")
fruitChart = {}
for i,temp in enumerate([x.strip().split(",") for x in f]):
   # since the first line is header, we need to filter it out
   if i==0:
      continue
   fruitChart[tuple(temp[0:2])] = temp[2]

# to access the items ...
fruitChart[("Apple","medium")] # returns the value "60"

f.close() # close the file to release the resources.
