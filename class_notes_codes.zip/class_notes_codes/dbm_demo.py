# demonstrate functionalities of dbm package
import dbm

# open a database file
# the "c" indicates that if the file is not found,
# a new file will be created
db = dbm.open("t1_dbm","c")

# write some value to a database
db["apple"] = "80"

# get the value back
db.get("apple")
# OR
db["apple"]

# to decode the byte object
db.get("apple").decode("utf-8")

# to remove item from database
del(db["apple"])

# close database
db.close()
